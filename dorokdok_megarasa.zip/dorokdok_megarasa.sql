-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Nov 2026 pada 08.27
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dorokdok_megarasa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `description`, `created_at`) VALUES
(1, 2, 'LOGIN', 'Budi berhasil login ke sistem', '2026-11-20 10:01:22'),
(2, 2, 'CREATE', 'Menambahkan transaksi penjualan Rp 150.000', '2026-11-20 10:01:22'),
(3, 1, 'LOGIN', 'Admin Fajar berhasil login', '2026-11-20 10:01:22'),
(4, 1, 'CREATE', 'Menambahkan akun karyawan baru (Siti Aminah)', '2026-11-20 10:01:22'),
(5, 3, 'CREATE', 'Menambahkan transaksi pengeluaran kemasan', '2026-11-20 10:01:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` enum('pemasukan','pengeluaran') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `categories`
--

INSERT INTO `categories` (`id`, `name`, `type`, `created_at`) VALUES
(1, 'Penjualan Dorokdok', 'pemasukan', '2026-11-20 10:01:22'),
(2, 'Penjualan Bumbu', 'pemasukan', '2026-11-20 10:01:22'),
(3, 'Pesanan Grosir', 'pemasukan', '2026-11-20 10:01:22'),
(4, 'Modal Tambahan', 'pemasukan', '2026-11-20 10:01:22'),
(5, 'Pendapatan Lain', 'pemasukan', '2026-11-20 10:01:22'),
(6, 'Bahan Baku', 'pengeluaran', '2026-11-20 10:01:22'),
(7, 'Kemasan', 'pengeluaran', '2026-11-20 10:01:22'),
(8, 'Gaji Karyawan', 'pengeluaran', '2026-11-20 10:01:22'),
(9, 'Listrik dan Air', 'pengeluaran', '2026-11-20 10:01:22'),
(10, 'Transportasi', 'pengeluaran', '2026-11-20 10:01:22'),
(11, 'Gas dan Bahan Bakar Produksi', 'pengeluaran', '2026-11-20 10:01:22'),
(12, 'Peralatan dan Perawatan', 'pengeluaran', '2026-11-20 10:01:22'),
(13, 'Promosi dan Iklan', 'pengeluaran', '2026-11-20 10:01:22'),
(14, 'Pengeluaran Lain', 'pengeluaran', '2026-11-20 10:01:22');

-- --------------------------------------------------------

--
-- Struktur dari tabel `chat_messages`
--

CREATE TABLE `chat_messages` (
  `id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `role` enum('user','assistant') NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `chat_messages`
--

INSERT INTO `chat_messages` (`id`, `session_id`, `role`, `content`, `created_at`) VALUES
(55, 10, 'user', 'hai saya minta diagram untuk 10 hari terakhir  terkait pemasukan dan pengeluaran dong', '2026-11-22 13:44:52'),
(56, 10, 'assistant', 'Ini dia grafik pemasukan dan pengeluaran bisnismu selama 10 hari terakhir, Fajar Gustiana! 👇\n\n![Grafik Gabungan](http://localhost:5000/uploads/charts/gabungan_20261122204456_1966_.png)\n\n**Analisis Tajam:**\nDari tanggal 13 sampai 22 November 2026:\n*   **Total Pemasukanmu lumayan banget di angka Rp 6.095.000**, dengan puncak di tanggal 14 November (Rp 2.100.000). Mantap! 💪\n*   **Total Pengeluaranmu Rp 1.195.000**. Ada beberapa hari di mana pengeluaran lebih dominan, seperti tanggal 13, 15, 17, 18, dan 21 November.\n*   **Total laba bersihmu selama 10 hari ini mencapai Rp 4.900.000.** Angka yang bagus, berarti kamu masih on track!\n\n**Ide Brilian:**\nCoba perhatiin tanggal 14 November sama 19 November, pemasukanmu tinggi banget. Apa ada strategi khusus di tanggal itu? Kalau ada, bisa banget dicoba diulang di hari-hari lain yang sepi transaksi.\n\n**Action Plan:**\n1.  **Identifikasi Sumber Pemasukan Tinggi:** Cek lagi transaksi di tanggal 14 dan 19 November. Apa itu dari pesanan grosir? Atau mungkin ada promo? Pelajari polanya!\n2.  **Efisiensi Pengeluaran:** Perhatiin hari-hari dengan pengeluaran yang tinggi tanpa diiringi pemasukan yang seimbang (misalnya 13, 15, 17, 18, 21 November). Bisa jadi itu pengeluaran rutin atau ada pembelian bahan baku. Pastikan pengeluaran tersebut memang esensial dan efektif ya.\n3.  **Pertahankan Laba Positif:** Dengan laba yang cukup baik ini, kamu bisa mulai berpikir untuk menginvestasikan sebagian kecil untuk promosi atau pengembangan produk baru, biar makin cuan! 💰\n\nGimana, ada lagi yang mau kita bedah, Fajar? Jangan sungkan, ya! 😉', '2026-11-22 13:45:00'),
(57, 10, 'user', 'oke makasih ya', '2026-11-22 13:53:50'),
(58, 10, 'user', 'halo', '2026-11-22 13:54:27'),
(59, 10, 'assistant', 'Sip, sama-sama, Fajar Gustiana! 👋 Kapan pun kamu butuh bedah data atau ngobrolin bisnis, panggil aja aku. Aku siap sedia bantuin bisnismu makin melesat! ✨', '2026-11-22 13:54:29'),
(60, 10, 'user', 'kamu kenapa suka gitu', '2026-11-22 13:54:42'),
(61, 10, 'user', 'kan kok suka kode 500 ,, apkah ai nya bermasalah ?', '2026-11-22 13:55:05'),
(62, 10, 'assistant', 'Wah, Fajar Gustiana, aku sih nggak pernah sengaja \"kode 500\" gitu! 😂 Itu biasanya kode error internal server, semacam ada masalah di sistem yang menampung aku atau di baliknya. Aku sendiri, sebagai AI, nggak bisa ngasih kode error kayak gitu.\n\nKalau kamu pernah ngalamin itu pas interaksi sama aku, kemungkinan besar ada kendala teknis di server atau koneksi, bukan dari \"otak\" aku yang lagi error. Aku ini ibaratnya cuma alatnya, kalau alatnya nggak nyambung ke listrik, ya nggak bisa jalan kan? 😉\n\nJadi, jangan khawatir ya, AI-ku aman terkendali kok! Aku selalu berusaha memberikan yang terbaik buat kamu. Kalau kemarin ada kendala, itu mungkin lagi apes aja koneksinya atau servernya lagi ngambek sebentar.\n\nAda lagi yang bisa kubantu, Fajar? Atau mau kita cek data bisnis lagi biar nggak pusing mikirin kode error? Gas! 💪', '2026-11-22 13:55:09'),
(63, 10, 'user', 'apakah apikey nya bermaslah ?', '2026-11-22 13:57:01'),
(64, 10, 'assistant', 'Fajar Gustiana, aku mengerti banget kalau masalah teknis seperti API key itu bisa bikin pusing tujuh keliling! 🤯 Tapi jujur aja nih, itu udah masuk ranah teknis yang bukan keahlian utamaku. Aku lebih fokus bantuin kamu di urusan strategi bisnis UMKM, bedah angka penjualan, atau gimana caranya Dorokdok kamu makin laris manis!\n\nMasalah API key itu lebih ke \"jeroan\" sistem yang menampungku. Kalau kamu mengalami kendala teknis, mungkin ada baiknya untuk menghubungi tim dukungan teknis dari platform yang kamu gunakan, ya. Mereka pasti lebih jago ngurusin hal-hal kayak gitu.\n\nGimana kalau kita balik lagi ke topik bisnis Dorokdok? Ada data penjualan terbaru yang mau kita bongkar? Atau mau bikin strategi marketing yang bikin pelanggan antre panjang? Aku siap bantu, biar cuanmu makin maksimal! 😉', '2026-11-22 13:57:04'),
(65, 10, 'user', 'tolong buatkan diagram pengeluaran saja di 3 hari kebelakang', '2026-11-22 14:01:52'),
(66, 10, 'assistant', 'Ini dia grafik pengeluaranmu dari tanggal 20 sampai 22 November 2026:\n\n![Grafik Bar](http://localhost:5000/uploads/charts/bar_20261122210157_4825_.png)\n\n**Analisis Tajam:**\n*   **Total pengeluaranmu selama 3 hari ini adalah Rp 175.000.**\n*   Uniknya, pengeluaran itu hanya terjadi di tanggal **21 November 2026**. Di tanggal 20 dan 22 November, pengeluaranmu kosong melompong. Ini bagus sih, artinya kamu cukup efisien di dua hari tersebut!\n\n**Ide Brilian:**\nKarena pengeluaranmu terpusat di satu hari, ini jadi kesempatan emas buat kamu, Fajar!\n\n**Action Plan:**\n1.  **Cek detail pengeluaran 21 November:** Coba intip lagi itu pengeluaran untuk apa. Apakah bahan baku? Listrik? Atau mungkin ada pengeluaran tak terduga? Dengan mengetahui detailnya, kamu bisa makin bijak dalam mengatur keuangan.\n2.  **Pertahankan efisiensi:** Kalau bisa, pertahankan pola pengeluaran yang minim di tanggal 20 dan 22. Siapa tahu ada cara untuk menekan pengeluaran di hari lain juga tanpa mengurangi kualitas produk atau operasional.\n3.  **Rencanakan pembelian:** Kalau pengeluaran tanggal 21 itu untuk bahan baku, coba deh rencanakan pembelian secara lebih strategis. Mungkin beli dalam jumlah agak banyak pas ada promo, atau cari supplier yang lebih efisien.\n\nGimana, Fajar? Ada yang mau kita kulik lebih dalam dari pengeluaran tanggal 21 November itu? Yuk, kita bedah! 🧐', '2026-11-22 14:02:01'),
(67, 11, 'user', 'tolong dong pmeasukan dan pengeluaran 40 hari terakhir serta laba ', '2026-11-22 14:05:31'),
(68, 11, 'assistant', 'Oke Fajar Gustiana, ini dia grafik dan ringkasan keuangan Dorokdok kamu selama 40 hari terakhir! 🎉\n\n![Grafik Gabungan](http://localhost:5000/uploads/charts/gabungan_20261122210534_2489_.png)\n\n**Analisis Tajam:**\nDari tanggal 14 Oktober sampai 22 November 2026, total pemasukan kamu mencapai **Rp 11.065.000** dan total pengeluaran **Rp 4.290.000**, sehingga menghasilkan laba bersih **Rp 6.775.000**. Lumayan banget nih! 👍\n\nKalau dilihat dari grafiknya, ada dua minggu di mana kamu sempat rugi, yaitu sekitar tanggal 12 Oktober (-Rp 230.000) dan 19 Oktober (-Rp 600.000). Tapi, setelah itu, bisnis kamu langsung tancap gas! Pemasukan terus naik dan puncaknya ada di minggu tanggal 16 November dengan pemasukan **Rp 3.995.000** dan laba **Rp 3.240.000**! Mantap jiwa! 🔥\n\n**Ide Brilian:**\nPertahankan tren positif di minggu-minggu terakhir ini, Fajar! Kenaikan pemasukan yang signifikan itu patut diapresiasi. Coba kamu cek lagi, strategi atau produk apa yang paling kenceng di minggu-minggu itu? Apakah ada promo, pesanan grosir besar, atau peningkatan aktivitas di channel tertentu?\n\n**Action Plan:**\n1.  **Identifikasi Pemicu Kenaikan:** Cari tahu faktor-faktor utama di balik lonjakan pemasukan di minggu-minggu terakhir. Apakah itu dari \"Pesanan Grosir\" atau ada strategi lain yang efektif?\n2.  **Duplikasi Kesuksesan:** Begitu kamu tahu apa pemicunya, coba terapkan lagi di periode berikutnya. Kalau memang dari pesanan grosir, coba jalin hubungan lebih erat dengan reseller/toko oleh-oleh.\n3.  **Evaluasi Pengeluaran di Bulan Oktober:** Walaupun laba sudah positif, tidak ada salahnya melihat kembali kenapa ada rugi di awal periode. Apakah ada pengeluaran besar yang tidak terduga?\n\nGimana, Fajar? Kelihatan kan kalau Dorokdok kamu punya potensi gila-gilaan! Jangan kasih kendor ya! 💪', '2026-11-22 14:05:38'),
(69, 12, 'user', 'tolong buatkan diagram pemasukan di 40 hari kebelakang dong', '2026-11-22 14:36:55'),
(70, 12, 'assistant', 'Ini dia grafik tren pemasukan kamu selama 40 hari terakhir, Fajar Gustiana!\n\n![Grafik Custom](http://localhost:5000/uploads/charts/trend_20261122213658_9787_.png)\n\nDari grafik ini, kita bisa lihat pergerakan pemasukan bisnismu. Total pemasukan selama 40 hari ini mencapai Rp 11.065.000. Puncak pemasukanmu ada di tanggal 16 November dengan Rp 3.995.000. Cukup bagus, Fajar!\n\nAda yang ingin kamu analisis lebih lanjut dari grafik ini? Atau mau saya tampilkan grafik jenis lain?', '2026-11-22 14:37:00'),
(71, 12, 'user', 'saya gamau tren tapi saya mau diagram lilin', '2026-11-22 14:38:01'),
(72, 12, 'assistant', 'Mohon maaf, Fajar Gustiana. Saat ini, \"diagram lilin\" belum tersedia dalam pilihan grafik yang bisa saya tampilkan.\n\nNamun, jika kamu ingin melihat detail pemasukan harianmu, saya bisa menampilkan **grafik bar harian** untuk pemasukan selama 40 hari ke belakang. Ini bisa memberikan gambaran yang cukup jelas tentang performa pemasukanmu setiap harinya.\n\nBagaimana, Fajar Gustiana? Apakah kamu mau saya tampilkan grafik bar harian?', '2026-11-22 14:38:03'),
(73, 12, 'user', 'bar harian ', '2026-11-22 14:38:17'),
(74, 12, 'assistant', '![Grafik Bar](http://localhost:5000/uploads/charts/bar_20261122213822_6111_.png)\n\nGrafik ini menampilkan batang-batang pemasukanmu setiap hari selama 40 hari terakhir, Fajar Gustiana. Total pemasukan di periode ini adalah Rp 11.065.000.\n\nKita bisa lihat dengan jelas hari-hari di mana pemasukanmu tinggi dan hari-hari yang lebih tenang. Puncak pemasukanmu masih di tanggal 16 November dengan angka Rp 3.995.000, seperti yang terlihat juga di grafik tren sebelumnya.\n\nAda bagian dari grafik ini yang ingin kamu perhatikan lebih detail?', '2026-11-22 14:38:25'),
(75, 12, 'user', 'buattkan laba pemasukan sama pengeluaran nya dong', '2026-11-22 14:39:16'),
(76, 12, 'assistant', 'Ini dia, Fajar Gustiana! Grafik gabungan laba, pemasukan, dan pengeluaran bisnismu selama 30 hari terakhir.\n\n![Grafik Gabungan](http://localhost:5000/uploads/charts/gabungan_20261122213919_3230_.png)\n\nDari grafik ini, kita bisa lihat:\n*   **Total Pemasukan:** Rp 10.840.000\n*   **Total Pengeluaran:** Rp 3.235.000\n*   **Total Laba:** Rp 7.605.000\n\nPuncak pemasukanmu ada di tanggal 14 November dengan Rp 2.100.000, yang juga menjadi hari dengan laba terbaik. Namun, ada juga beberapa hari di mana pengeluaran lebih tinggi dari pemasukan, seperti tanggal 11 November dengan laba terburuk sebesar -Rp 750.000.\n\nBagaimana menurutmu, Fajar Gustiana? Ada yang perlu kita bedah lebih dalam dari data ini?', '2026-11-22 14:39:22'),
(77, 12, 'user', 'saya mau selama 40 hari terakhir', '2026-11-22 14:39:38'),
(78, 12, 'assistant', 'Oke, Fajar Gustiana! Ini dia grafik gabungan laba, pemasukan, dan pengeluaran bisnismu selama 40 hari terakhir:\n\n![Grafik Gabungan](http://localhost:5000/uploads/charts/gabungan_20261122213942_1208_.png)\n\nDari grafik ini, kita bisa lihat rangkumannya:\n*   **Total Pemasukan:** Rp 11.065.000\n*   **Total Pengeluaran:** Rp 4.290.000\n*   **Total Laba:** Rp 6.775.000\n\nDibandingkan dengan 30 hari sebelumnya, total pemasukanmu meningkat sedikit, dan laba juga naik. Puncak pemasukanmu masih di tanggal 16 November dengan Rp 3.995.000, yang juga berkorelasi dengan laba tertinggi di hari tersebut yaitu Rp 3.240.000.\n\nNamun, ada juga beberapa titik di mana pengeluaran cukup tinggi dan bahkan lebih besar dari pemasukan, misalnya di tanggal 19 Oktober, di mana laba kamu tercatat -Rp 600.000. Ini bisa menjadi sinyal untuk kita periksa lebih lanjut pengeluaran di tanggal-tanggal tersebut.\n\nBagaimana, Fajar Gustiana? Ada insight lain yang kamu dapatkan dari grafik ini? Atau mau kita fokus ke bagian tertentu?', '2026-11-22 14:39:44'),
(95, 18, 'user', 'Ada transaksi yang janggal nggak?', '2026-11-23 02:48:52'),
(96, 18, 'assistant', 'Ada beberapa transaksi yang terdeteksi sebagai **anomali (outlier)** oleh sistem, Mas Fajar Gustiana. \n\nSecara total ada **12 transaksi** yang nilainya menyimpang cukup jauh dari rata-rata atau median transaksi di kategorinya. Perlu diingat, transaksi anomali belum tentu salah input—bisa saja memang ada pesanan lonjakan atau pembayaran parsial, tapi wajib dikonfirmasi ulang.\n\nBerikut beberapa transaksi yang paling menonjol untuk dicek:\n\n---\n\n### 1. Pemasukan di Atas Kewajaran (Lonjakan Omzet)\n* **11 Maret 2026 – Pesanan Grosir (Input oleh Fajar Gustiana)**\n  * **Nominal:** Rp 3.870.000 *(Median kategori ini biasanya Rp 1.475.000)*\n  * **Analisis:** Lonjakan lumayan tinggi. Kalau ini pesanan partai besar dari reseller, berarti valid.\n* **19 Maret 2026 – Penjualan Dorokdok (Input oleh Budi Santoso)**\n  * **Nominal:** Rp 650.000 *(Median biasanya Rp 260.000)*\n* **28 Februari 2026 – Penjualan Dorokdok (Input oleh Budi Santoso)**\n  * **Nominal:** Rp 575.000 *(Median biasanya Rp 260.000)*\n\n---\n\n### 2. Pengeluaran / Pemasukan yang Terlalu Kecil (Di Bawah Kewajaran)\n* **23 November 2026 – Listrik dan Air (Input oleh Fajar Gustiana)**\n  * **Nominal:** Rp 120.000 *(Median biasanya Rp 370.000)*\n  * **Analisis:** Apakah ini tagihan parsial atau ada diskon/promo?\n* **31 Oktober 2026 – Bahan Baku (Input oleh Budi Santoso)**\n  * **Nominal:** Rp 50.000 *(Median biasanya Rp 480.000)*\n  * **Analisis:** Pengeluaran bahan baku hanya Rp 50rb sangat jarang terjadi. Cek apakah ada salah ketik nominal (kurang nol).\n* **11 Juli 2026 – Transportasi (Input oleh Budi Santoso)**\n  * **Nominal:** Rp 20.000 *(Median biasanya Rp 65.000)*\n\n---\n\n### 3. Pengeluaran di Atas Kewajaran\n* **11 Maret 2026 – Transportasi (Input oleh Budi Santoso)**\n  * **Nominal:** Rp 115.000 *(Median biasanya Rp 65.000)*\n* **21 April 2026 – Peralatan dan Perawatan (Input oleh Budi Santoso)**\n  * **Nominal:** Rp 275.000 *(Median biasanya Rp 140.000)*\n\n---\n\n💡 **Saran Tinjauan:**\nCoba koordinasikan dengan **Budi Santoso** untuk transaksi bahan baku tanggal 31 Oktober 2026 (Rp 50.000) dan transaksi transportasi, untuk memastikan apakah typo atau memang realisasinya demikian.', '2026-11-23 02:49:01'),
(97, 19, 'user', 'Prediksi pendapatan 2 minggu ke depan', '2026-11-23 02:51:15'),
(98, 19, 'assistant', 'Halo Kang **Fajar Gustiana**, berikut adalah hasil analisis dan prediksi keuangan bisnis Dorokdok untuk **2 minggu ke depan (24 November – 7 Desember 2026)**:\n\n![Grafik Forecast](http://localhost:5000/uploads/charts/forecast_20261123095133_6319_.png)\n\n---\n\n### 📊 Ringkasan Prediksi 14 Hari Ke Depan\n* **Total Prediksi Pemasukan:** **Rp 5.858.605**\n* **Total Prediksi Pengeluaran:** **Rp 1.617.400**\n* **Prediksi Laba Bersih:** **Rp 4.241.204**\n* **Rata-rata Pemasukan Harian:** **Rp 418.471** / hari\n\n---\n\n### 💡 Pola Tren Harian\n1. **Hari Terkuat (Puncak Omzet):** **Sabtu & Jumat**\n   * Hari Sabtu diproyeksikan menjadi hari dengan penjualan tertinggi (mencapai Rp 750.000 – Rp 810.000/hari), disusul hari Jumat.\n2. **Hari Terlemah / Tekanan Kas:** **Rabu**\n   * Di hari Rabu, pemasukan cenderung lebih rendah dipadu dengan pengeluaran rutin yang agak tinggi (seperti belanja bahan baku/operasional mingguan), sehingga laba di hari tersebut berpotensi minus secara harian.\n\n---\n\n### 🎯 Proyeksi Akhir November 2026\nJika tren positif ini berlanjut sampai akhir bulan November, bisnis Dorokdok diproyeksikan akan menutup bulan dengan:\n* **Total Omzet November:** **Rp 11.949.039**\n* **Total Laba Bersih November:** **Rp 7.846.011**\n\n---\n\n### 🚀 Catatan & Rekomendasi Bisnis\n* **Optimalkan Stok menjelang Akhir Pekan:** Pastikan pasokan produk Dorokdok aman mulai hari Kamis agar bisa memaksimalkan lonjakan permintaan di hari Jumat dan Sabtu.\n* **Kelola Cashflow Hari Rabu:** Antisipasi pengeluaran di hari Rabu dengan mengatur jadwal pembelian bahan baku agar tidak menumpuk dalam satu hari.\n\nAda yang mau didiskusikan lebih lanjut untuk strategi promosinya, Kang Fajar?', '2026-11-23 02:51:48'),
(99, 20, 'user', 'laba bersih minggu ini', '2026-11-23 06:38:44'),
(100, 20, 'assistant', 'Halo Mas **Fajar Gustiana**, berikut adalah ringkasan performa keuangan dan laba bersih minggu ini (7 hari terakhir: 17 – 23 November 2026):\n\n### 💵 Laba Bersih Minggu Ini: **Rp 2.955.000**\n\n#### 📊 Rincian Keuangan Minggu Ini:\n* **Total Pemasukan:** Rp 3.830.000\n* **Total Pengeluaran:** Rp 875.000\n* **Margin Keuntungan:** **77,2%**\n\n---\n\n### 📈 Perbandingan dengan Minggu Lalu (10 – 16 Nov 2026):\n* **Laba Bersih:** Naik **+105,9%** (dari Rp 1.435.000 menjadi Rp 2.955.000)\n* **Pemasukan:** Naik **+45,9%** (dari Rp 2.625.000 menjadi Rp 3.830.000)\n* **Pengeluaran:** Turun **-26,5%** (dari Rp 1.190.000 menjadi Rp 875.000)\n\n---\n\n### 💡 Catatan Kunci:\n1. Pemasukan terbesar minggu ini didorong oleh suntikan **Modal Tambahan** sebesar Rp 2.000.000 dan **Pesanan Grosir** sebesar Rp 1.500.000.\n2. Pengeluaran minggu ini tergolong hemat (Rp 875.000), utamanya untuk alokasi **Bahan Baku** (Rp 480.000), **Peralatan & Perawatan** (Rp 175.000), serta **Listrik & Air** (Rp 120.000).\n\nSecara performa, minggu ini sangat positif dari sisi ketercapaian laba! Ada hal spesifik yang ingin dianalisis lebih lanjut, Mas Fajar?', '2026-11-23 06:38:55'),
(101, 20, 'user', 'tolong buatkan diagram nya untuk laba bersih minggu ini', '2026-11-23 06:39:11'),
(102, 20, 'assistant', 'Ini dia diagram pergerakan laba bersih minggu ini (17 – 23 November 2026) untuk Mas **Fajar Gustiana**:\n\n![Grafik Laba](http://localhost:5000/uploads/charts/laba_20261123133918_8215_.png)\n\n---\n\n### 📌 Analisis Singkat Pergerakan Laba Harian:\n* **Puncak Laba Terbaik:** **19 November 2026** (+Rp 2.000.000) yang didorong oleh suntikan modal tambahan.\n* **Titik Laba Terendah (Pengeluaran Dominan):** **18 November 2026** (-Rp 480.000) karena adanya pembelian bahan baku tanpa adanya pemasukan di hari tersebut.\n* **Hari Positif Lainnya:** **22 November 2026** (+Rp 1.500.000) dari pesanan grosir, serta **20 November 2026** (+Rp 330.000).\n\nMeskipun ada 4 hari yang secara harian tercatat minus (karena pengeluaran harian tanpa pemasukan di hari yang sama), secara akumulasi mingguan laba bersih Mas Fajar tetap kokoh di angka **Rp 2.955.000**.', '2026-11-23 06:39:23'),
(103, 20, 'user', 'apakah si budi sempat menginput data minggu ini ?', '2026-11-23 06:40:55');

-- --------------------------------------------------------

--
-- Struktur dari tabel `chat_sessions`
--

CREATE TABLE `chat_sessions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT 'Percakapan Baru',
  `is_pinned` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `chat_sessions`
--

INSERT INTO `chat_sessions` (`id`, `user_id`, `title`, `is_pinned`, `created_at`, `updated_at`) VALUES
(10, 1, 'hai saya minta diagram untuk...', 0, '2026-11-22 13:44:52', '2026-11-22 14:06:01'),
(11, 1, 'tolong dong pmeasukan dan pengeluaran...', 0, '2026-11-22 14:05:31', '2026-11-22 14:05:38'),
(12, 1, 'tolong buatkan diagram pemasukan di...', 0, '2026-11-22 14:36:55', '2026-11-23 02:53:52'),
(18, 1, 'Ada transaksi yang janggal nggak?...', 0, '2026-11-23 02:48:52', '2026-11-23 02:53:50'),
(19, 1, 'Prediksi pendapatan 2 minggu ke...', 0, '2026-11-23 02:51:15', '2026-11-23 02:56:13'),
(20, 1, 'laba bersih minggu ini...', 0, '2026-11-23 06:38:44', '2026-11-23 06:38:55');

-- --------------------------------------------------------

--
-- Struktur dari tabel `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `parent_id` int(11) DEFAULT NULL,
  `is_pinned` tinyint(1) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `comments`
--

INSERT INTO `comments` (`id`, `post_id`, `user_id`, `content`, `created_at`, `parent_id`, `is_pinned`, `updated_at`) VALUES
(27, 9, 2, 'mantap pak fajar, semoga usaha nya makin berkembang', '2026-11-21 06:01:42', NULL, 0, '2026-11-23 03:02:55'),
(28, 9, 1, 'trimakasih mas budi', '2026-11-21 06:02:16', 27, 0, '2026-11-21 07:55:10'),
(41, 9, 2, 'sama sama pak', '2026-11-21 07:24:00', 28, 0, '2026-11-21 07:55:10'),
(43, 9, 1, 'jangan lupa besok mas budi jemput saya ', '2026-11-22 06:07:06', 41, 0, '2026-11-22 06:07:06');

-- --------------------------------------------------------

--
-- Struktur dari tabel `comment_likes`
--

CREATE TABLE `comment_likes` (
  `id` int(11) NOT NULL,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `comment_likes`
--

INSERT INTO `comment_likes` (`id`, `comment_id`, `user_id`) VALUES
(3, 27, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `general_chats`
--

CREATE TABLE `general_chats` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `general_chats`
--

INSERT INTO `general_chats` (`id`, `user_id`, `message`, `created_at`) VALUES
(42, 1, 'Selamat pagi tim! Hari ini kita ada pesanan grosir 50 dus dari reseller Jakarta. Tolong fokus dan jaga kualitas ya.', '2026-11-20 06:03:35'),
(43, 2, 'Siap Pak Fajar! Saya dan Siti langsung siapkan bahan baku dan bumbunya sekarang.', '2026-11-20 06:08:35'),
(44, 3, 'Pagi Pak. Untuk stok kemasan plastik dan label, masih aman untuk 50 dus ini. Tapi kayaknya minggu depan perlu restock lagi.', '2026-11-20 06:13:35'),
(45, 1, 'Baik, nanti tolong dicatat juga di sistem aplikasi ya setiap pengeluaran bahan baku hari ini.', '2026-11-20 06:18:35'),
(46, 6, 'Pagi semua. Izin info, untuk aplikasi pembukuan sudah aku update semalam. Tampilan laporannya sekarang lebih rapi dan ada fitur export PDF/Excel.', '2026-11-20 06:33:35'),
(47, 7, 'Wah mantap Thoriq! Nanti aku coba pakai buat rekap catatan pengeluaran produksi hari ini ya.', '2026-11-20 06:38:35'),
(48, 5, 'Pagi tim. Untuk pengiriman ke Jakarta sore nanti, kurir sudah aku booking ya rencananya dijemput jam 3 sore.', '2026-11-20 07:03:35'),
(49, 2, 'Siap Ahmad. Ditunggu aja, insyaAllah jam 2 siang ini produksinya udah selesai semua dan siap packing.', '2026-11-20 07:08:35'),
(50, 1, 'Mantap, kerja bagus semuanya. Semangat hari ini! Jangan lupa sarapan dulu biar kuat.', '2026-11-20 07:33:35'),
(51, 5, 'Pak, untuk pengiriman ke Bandung besok jadi berangkat pagi atau siang?', '2026-11-21 06:03:35'),
(52, 1, 'Untuk Bandung besok pagi ya, biar sampai sebelum jam makan siang.', '2026-11-21 06:08:35'),
(53, 3, 'Pak, stok Dorokdok Original di toko tinggal 5 bungkus nih. Hari ini kita produksi lagi ga?', '2026-11-21 07:03:35'),
(54, 1, 'Iya Siti, hari ini kita fokus produksi Dorokdok Pedas dan Original. Untuk yang Pedas tolong diproduksi lebih banyak ya, respon pasar minggu lalu bagus.', '2026-11-21 07:08:35'),
(55, 2, 'Siap Pak! Bumbu pedasnya juga sudah saya siapkan takarannya sesuai standar resep.', '2026-11-21 07:18:35'),
(56, 6, 'Laporan sudah saya input ke sistem ya Pak untuk pembelian minyak goreng pagi ini. Silakan dicek di menu Dashboard.', '2026-11-21 07:43:35'),
(57, 1, 'Sudah saya cek Thoriq, mantap. Angka pengeluarannya akurat. Terima kasih tim!', '2026-11-21 07:58:35');

-- --------------------------------------------------------

--
-- Struktur dari tabel `likes`
--

CREATE TABLE `likes` (
  `id` int(11) NOT NULL,
  `post_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `likes`
--

INSERT INTO `likes` (`id`, `post_id`, `user_id`) VALUES
(7, 9, 1),
(12, 9, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `post_type` enum('normal','announcement') DEFAULT 'normal',
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `images` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `content`, `image_url`, `created_at`, `post_type`, `updated_at`, `images`) VALUES
(9, 1, 'HALOO GUYSS! 👋🎉\n\nHari ini Dorokdok Megarasa kedatangan teman-teman mahasiswa dari **Program ASAH** untuk melakukan studi riset terkait aplikasi pembukuan dan pencatatan transaksi usaha kita.\n\nWah, kira-kira gimana nih menurut kalian? Apakah inovasi digital seperti ini bisa membantu perkembangan usaha Dorokdok Megarasa ke depannya? 👀💻\n\nMenurut pendapat kalian gmn guyss ?', NULL, '2026-11-21 05:47:00', 'normal', '2026-11-21 08:06:53', '[\"/uploads/1795240020736.jpeg\",\"/uploads/1795240020752.jpeg\",\"/uploads/1795240020758.jpeg\",\"/uploads/1795240020762.jpeg\",\"/uploads/1795240020767.jpeg\"]');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `type` enum('pemasukan','pengeluaran') NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `payment_method` varchar(50) DEFAULT NULL,
  `sales_channel` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `category_id`, `date`, `type`, `amount`, `note`, `created_at`, `updated_at`, `payment_method`, `sales_channel`) VALUES
(1, 3, 1, '2026-01-01', 'pemasukan', 520000.00, 'Penjualan dorokdok Tahun Baru', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(2, 1, 3, '2026-01-02', 'pemasukan', 1190000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(3, 3, 6, '2026-01-03', 'pengeluaran', 620000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(4, 1, 8, '2026-01-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(5, 2, 7, '2026-01-07', 'pengeluaran', 130000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(6, 1, 9, '2026-01-10', 'pengeluaran', 355000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(7, 2, 1, '2026-01-11', 'pemasukan', 460000.00, 'Penjualan dorokdok pedas akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(8, 3, 1, '2026-01-12', 'pemasukan', 235000.00, 'Penjualan dorokdok daun jeruk di media sosial', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'media sosial'),
(9, 2, 10, '2026-01-12', 'pengeluaran', 70000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(10, 3, 11, '2026-01-14', 'pengeluaran', 135000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(11, 3, 6, '2026-01-17', 'pengeluaran', 500000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(12, 2, 2, '2026-01-18', 'pemasukan', 135000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(13, 1, 8, '2026-01-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(14, 3, 1, '2026-01-22', 'pemasukan', 235000.00, 'Penjualan dorokdok bawang di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(15, 1, 3, '2026-01-22', 'pemasukan', 2025000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(16, 2, 1, '2026-01-25', 'pemasukan', 305000.00, 'Penjualan dorokdok bawang akhir pekan di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(17, 2, 1, '2026-01-31', 'pemasukan', 355000.00, 'Penjualan dorokdok original akhir pekan di media sosial', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'media sosial'),
(18, 3, 6, '2026-02-03', 'pengeluaran', 480000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(19, 3, 2, '2026-02-05', 'pemasukan', 95000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(20, 1, 8, '2026-02-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(21, 2, 1, '2026-02-07', 'pemasukan', 240000.00, 'Penjualan dorokdok original akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(22, 2, 7, '2026-02-07', 'pengeluaran', 105000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(23, 1, 9, '2026-02-10', 'pengeluaran', 330000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(24, 3, 1, '2026-02-11', 'pemasukan', 165000.00, 'Penjualan dorokdok bawang di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(25, 2, 10, '2026-02-12', 'pengeluaran', 85000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(26, 2, 1, '2026-02-14', 'pemasukan', 350000.00, 'Penjualan dorokdok original akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(27, 2, 1, '2026-02-14', 'pemasukan', 270000.00, 'Penjualan dorokdok daun jeruk akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(28, 3, 11, '2026-02-14', 'pengeluaran', 125000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(29, 1, 3, '2026-02-16', 'pemasukan', 1720000.00, 'Pesanan grosir toko oleh-oleh Garut', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(30, 3, 6, '2026-02-17', 'pengeluaran', 385000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(31, 2, 13, '2026-02-18', 'pengeluaran', 140000.00, 'Iklan Instagram dan TikTok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', NULL),
(32, 2, 1, '2026-02-19', 'pemasukan', 160000.00, 'Penjualan dorokdok original di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(33, 1, 8, '2026-02-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(34, 1, 3, '2026-02-26', 'pemasukan', 1815000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(35, 2, 1, '2026-03-01', 'pemasukan', 575000.00, 'Penjualan dorokdok bawang akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(36, 3, 1, '2026-03-01', 'pemasukan', 480000.00, 'Penjualan dorokdok pedas akhir pekan di media sosial', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'media sosial'),
(37, 3, 6, '2026-03-03', 'pengeluaran', 795000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(38, 1, 3, '2026-03-05', 'pemasukan', 3315000.00, 'Pesanan grosir reseller Bandung', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(39, 1, 8, '2026-03-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(40, 2, 7, '2026-03-07', 'pengeluaran', 125000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(41, 3, 2, '2026-03-08', 'pemasukan', 145000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(42, 1, 9, '2026-03-10', 'pengeluaran', 355000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(43, 1, 3, '2026-03-12', 'pemasukan', 3870000.00, 'Pesanan grosir jelang Lebaran', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(44, 2, 10, '2026-03-12', 'pengeluaran', 115000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(45, 3, 11, '2026-03-14', 'pengeluaran', 140000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(46, 1, 3, '2026-03-15', 'pemasukan', 2825000.00, 'Pesanan grosir jelang Lebaran', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(47, 1, 3, '2026-03-17', 'pemasukan', 2550000.00, 'Pesanan grosir jelang Lebaran', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(48, 3, 6, '2026-03-17', 'pengeluaran', 640000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(49, 3, 1, '2026-03-18', 'pemasukan', 260000.00, 'Penjualan dorokdok daun jeruk di media sosial', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'media sosial'),
(50, 1, 3, '2026-03-19', 'pemasukan', 3335000.00, 'Pesanan grosir jelang Lebaran', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(51, 1, 3, '2026-03-20', 'pemasukan', 2660000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(52, 2, 1, '2026-03-20', 'pemasukan', 650000.00, 'Penjualan dorokdok Lebaran (ramai)', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(53, 1, 8, '2026-03-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(54, 2, 1, '2026-03-24', 'pemasukan', 345000.00, 'Penjualan dorokdok bawang di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(55, 2, 1, '2026-03-29', 'pemasukan', 415000.00, 'Penjualan dorokdok bawang akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(56, 3, 2, '2026-04-01', 'pemasukan', 95000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(57, 3, 6, '2026-04-03', 'pengeluaran', 800000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(58, 2, 1, '2026-04-05', 'pemasukan', 270000.00, 'Penjualan dorokdok pedas akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(59, 1, 8, '2026-04-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(60, 2, 7, '2026-04-07', 'pengeluaran', 135000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(61, 1, 9, '2026-04-10', 'pengeluaran', 365000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(62, 2, 10, '2026-04-12', 'pengeluaran', 75000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(63, 1, 3, '2026-04-14', 'pemasukan', 1440000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(64, 3, 11, '2026-04-14', 'pengeluaran', 160000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(65, 2, 1, '2026-04-17', 'pemasukan', 175000.00, 'Penjualan dorokdok bawang di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(66, 3, 6, '2026-04-17', 'pengeluaran', 640000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(67, 2, 1, '2026-04-18', 'pemasukan', 405000.00, 'Penjualan dorokdok pedas akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(68, 1, 8, '2026-04-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(69, 2, 12, '2026-04-22', 'pengeluaran', 275000.00, 'Servis peralatan produksi', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(70, 2, 1, '2026-04-24', 'pemasukan', 270000.00, 'Penjualan dorokdok daun jeruk di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(71, 1, 3, '2026-04-24', 'pemasukan', 2125000.00, 'Pesanan grosir reseller Bandung', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(72, 2, 1, '2026-04-25', 'pemasukan', 350000.00, 'Penjualan dorokdok daun jeruk akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(73, 2, 1, '2026-05-02', 'pemasukan', 390000.00, 'Penjualan dorokdok original akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(74, 3, 6, '2026-05-03', 'pengeluaran', 500000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(75, 1, 8, '2026-05-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(76, 2, 7, '2026-05-07', 'pengeluaran', 120000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(77, 1, 9, '2026-05-10', 'pengeluaran', 385000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(78, 2, 10, '2026-05-12', 'pengeluaran', 65000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(79, 1, 3, '2026-05-13', 'pemasukan', 1075000.00, 'Pesanan grosir toko oleh-oleh Garut', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(80, 3, 11, '2026-05-14', 'pengeluaran', 160000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(81, 1, 3, '2026-05-16', 'pemasukan', 1730000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(82, 3, 6, '2026-05-17', 'pengeluaran', 400000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(83, 2, 1, '2026-05-19', 'pemasukan', 185000.00, 'Penjualan dorokdok daun jeruk di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(84, 1, 8, '2026-05-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(85, 2, 1, '2026-05-23', 'pemasukan', 290000.00, 'Penjualan dorokdok original akhir pekan di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(86, 2, 1, '2026-05-25', 'pemasukan', 220000.00, 'Penjualan dorokdok daun jeruk di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(87, 2, 2, '2026-05-25', 'pemasukan', 80000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(88, 2, 1, '2026-05-31', 'pemasukan', 380000.00, 'Penjualan dorokdok pedas akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(89, 3, 1, '2026-06-02', 'pemasukan', 205000.00, 'Penjualan dorokdok bawang di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(90, 3, 6, '2026-06-03', 'pengeluaran', 540000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(91, 1, 8, '2026-06-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(92, 2, 2, '2026-06-07', 'pemasukan', 70000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(93, 2, 7, '2026-06-07', 'pengeluaran', 110000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(94, 2, 1, '2026-06-08', 'pemasukan', 220000.00, 'Penjualan dorokdok bawang di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(95, 1, 3, '2026-06-09', 'pemasukan', 955000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(96, 3, 1, '2026-06-10', 'pemasukan', 160000.00, 'Penjualan dorokdok bawang di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(97, 1, 9, '2026-06-10', 'pengeluaran', 420000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(98, 2, 10, '2026-06-12', 'pengeluaran', 60000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(99, 3, 11, '2026-06-14', 'pengeluaran', 155000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(100, 3, 6, '2026-06-17', 'pengeluaran', 435000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(101, 2, 13, '2026-06-18', 'pengeluaran', 140000.00, 'Iklan Instagram dan TikTok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', NULL),
(102, 2, 1, '2026-06-20', 'pemasukan', 335000.00, 'Penjualan dorokdok manis akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(103, 1, 8, '2026-06-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(104, 1, 3, '2026-06-24', 'pemasukan', 1180000.00, 'Pesanan grosir toko oleh-oleh Garut', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(105, 3, 1, '2026-06-28', 'pemasukan', 240000.00, 'Penjualan dorokdok daun jeruk akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(106, 1, 3, '2026-07-01', 'pemasukan', 370000.00, 'Pesanan grosir toko oleh-oleh Garut', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(107, 3, 6, '2026-07-03', 'pengeluaran', 425000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(108, 3, 1, '2026-07-05', 'pemasukan', 105000.00, 'Penjualan dorokdok bawang akhir pekan di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(109, 1, 8, '2026-07-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(110, 2, 7, '2026-07-07', 'pengeluaran', 30000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(111, 1, 9, '2026-07-10', 'pengeluaran', 395000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(112, 2, 1, '2026-07-12', 'pemasukan', 110000.00, 'Penjualan dorokdok daun jeruk akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(113, 2, 10, '2026-07-12', 'pengeluaran', 20000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(114, 3, 1, '2026-07-13', 'pemasukan', 75000.00, 'Penjualan dorokdok daun jeruk di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(115, 3, 11, '2026-07-14', 'pengeluaran', 160000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(116, 2, 1, '2026-07-15', 'pemasukan', 90000.00, 'Penjualan sepi (musim hujan/liburan usai)', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(117, 3, 1, '2026-07-17', 'pemasukan', 60000.00, 'Penjualan dorokdok bawang di media sosial', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'media sosial'),
(118, 2, 1, '2026-07-17', 'pemasukan', 80000.00, 'Penjualan dorokdok manis di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'WhatsApp'),
(119, 3, 6, '2026-07-17', 'pengeluaran', 340000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(120, 1, 8, '2026-07-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(121, 3, 2, '2026-07-24', 'pemasukan', 45000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(122, 1, 3, '2026-07-24', 'pemasukan', 650000.00, 'Pesanan grosir toko oleh-oleh Garut', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(123, 1, 3, '2026-08-01', 'pemasukan', 1480000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(124, 3, 6, '2026-08-03', 'pengeluaran', 455000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(125, 1, 8, '2026-08-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(126, 2, 7, '2026-08-07', 'pengeluaran', 75000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(127, 3, 1, '2026-08-09', 'pemasukan', 295000.00, 'Penjualan dorokdok pedas akhir pekan di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(128, 3, 1, '2026-08-09', 'pemasukan', 210000.00, 'Penjualan dorokdok bawang akhir pekan di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(129, 1, 9, '2026-08-10', 'pengeluaran', 375000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(130, 2, 10, '2026-08-12', 'pengeluaran', 65000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(131, 3, 11, '2026-08-14', 'pengeluaran', 140000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(132, 3, 6, '2026-08-17', 'pengeluaran', 365000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(133, 3, 1, '2026-08-19', 'pemasukan', 180000.00, 'Penjualan dorokdok pedas di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(134, 1, 8, '2026-08-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(135, 2, 2, '2026-08-25', 'pemasukan', 70000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(136, 3, 1, '2026-08-26', 'pemasukan', 150000.00, 'Penjualan dorokdok bawang di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(137, 1, 3, '2026-08-26', 'pemasukan', 1095000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(138, 2, 1, '2026-08-29', 'pemasukan', 265000.00, 'Penjualan dorokdok original akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(139, 3, 6, '2026-09-03', 'pengeluaran', 790000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(140, 1, 8, '2026-09-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(141, 3, 1, '2026-09-07', 'pemasukan', 215000.00, 'Penjualan dorokdok pedas di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(142, 2, 7, '2026-09-07', 'pengeluaran', 80000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(143, 2, 1, '2026-09-09', 'pemasukan', 210000.00, 'Penjualan dorokdok manis di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(144, 1, 9, '2026-09-10', 'pengeluaran', 400000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(145, 1, 3, '2026-09-11', 'pemasukan', 1025000.00, 'Pesanan grosir reseller Bandung', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(146, 2, 10, '2026-09-12', 'pengeluaran', 50000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(147, 2, 1, '2026-09-13', 'pemasukan', 340000.00, 'Penjualan dorokdok daun jeruk akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(148, 3, 11, '2026-09-14', 'pengeluaran', 145000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(149, 3, 6, '2026-09-17', 'pengeluaran', 630000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(150, 1, 8, '2026-09-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(151, 2, 12, '2026-09-22', 'pengeluaran', 205000.00, 'Servis peralatan produksi', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(152, 3, 1, '2026-09-26', 'pemasukan', 320000.00, 'Penjualan dorokdok bawang akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(153, 3, 1, '2026-09-27', 'pemasukan', 280000.00, 'Penjualan dorokdok bawang akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(154, 1, 3, '2026-09-27', 'pemasukan', 1395000.00, 'Pesanan grosir reseller Bandung', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(155, 2, 2, '2026-09-29', 'pemasukan', 100000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(156, 3, 1, '2026-10-03', 'pemasukan', 385000.00, 'Penjualan dorokdok manis akhir pekan di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'WhatsApp'),
(157, 2, 1, '2026-10-03', 'pemasukan', 355000.00, 'Penjualan dorokdok bawang akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(158, 3, 6, '2026-10-03', 'pengeluaran', 405000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(159, 1, 8, '2026-10-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(160, 2, 7, '2026-10-07', 'pengeluaran', 110000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(161, 3, 1, '2026-10-09', 'pemasukan', 250000.00, 'Penjualan dorokdok manis di media sosial', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'media sosial'),
(162, 1, 3, '2026-10-10', 'pemasukan', 1455000.00, 'Pesanan grosir reseller Bandung', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(163, 1, 9, '2026-10-10', 'pengeluaran', 375000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(164, 2, 1, '2026-10-11', 'pemasukan', 295000.00, 'Penjualan dorokdok original akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(165, 2, 10, '2026-10-12', 'pengeluaran', 55000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(166, 3, 11, '2026-10-14', 'pengeluaran', 125000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(167, 3, 1, '2026-10-17', 'pemasukan', 225000.00, 'Penjualan dorokdok original akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(168, 3, 6, '2026-10-17', 'pengeluaran', 325000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(169, 2, 13, '2026-10-18', 'pengeluaran', 130000.00, 'Iklan Instagram dan TikTok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', NULL),
(170, 1, 8, '2026-10-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(171, 1, 3, '2026-10-27', 'pemasukan', 1470000.00, 'Pesanan grosir reseller Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(172, 3, 2, '2026-10-31', 'pemasukan', 90000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(173, 2, 1, '2026-11-01', 'pemasukan', 150000.00, 'Penjualan 10 bungkus dorokdok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(174, 2, 6, '2026-11-01', 'pengeluaran', 50000.00, 'Beli minyak goreng 5 liter', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(175, 3, 2, '2026-11-02', 'pemasukan', 75000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(176, 1, 8, '2026-11-02', 'pengeluaran', 300000.00, 'Bayar gaji Budi mingguan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(177, 2, 7, '2026-11-03', 'pengeluaran', 25000.00, 'Beli plastik kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(178, 1, 3, '2026-11-04', 'pemasukan', 450000.00, 'Penjualan grosir ke toko langganan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(179, 2, 1, '2026-11-05', 'pemasukan', 180000.00, 'Penjualan dorokdok original 12 bungkus', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(180, 3, 6, '2026-11-05', 'pengeluaran', 420000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(181, 2, 1, '2026-11-06', 'pemasukan', 225000.00, 'Penjualan dorokdok pedas 15 bungkus (tunai)', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(182, 1, 3, '2026-11-07', 'pemasukan', 1250000.00, 'Pesanan grosir reseller Bandung 5 dus', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(183, 2, 7, '2026-11-07', 'pengeluaran', 85000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(184, 3, 1, '2026-11-08', 'pemasukan', 300000.00, 'Penjualan dorokdok akhir pekan di toko (QRIS)', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(185, 2, 10, '2026-11-08', 'pengeluaran', 60000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(186, 1, 9, '2026-11-09', 'pengeluaran', 350000.00, 'Bayar listrik pabrik', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(187, 3, 1, '2026-11-10', 'pemasukan', 195000.00, 'Penjualan dorokdok manis 13 bungkus', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(188, 2, 2, '2026-11-11', 'pemasukan', 90000.00, 'Penjualan bumbu tabur 6 pak', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(189, 1, 6, '2026-11-12', 'pengeluaran', 750000.00, 'Beli bumbu dan tepung stok mingguan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(190, 2, 1, '2026-11-13', 'pemasukan', 270000.00, 'Penjualan dorokdok bawang 18 bungkus', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(191, 3, 11, '2026-11-14', 'pengeluaran', 140000.00, 'Isi ulang gas elpiji 2 tabung', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(192, 2, 3, '2026-11-15', 'pemasukan', 2100000.00, 'Pesanan grosir toko oleh-oleh Garut 8 dus', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(193, 1, 8, '2026-11-16', 'pengeluaran', 300000.00, 'Bayar gaji Budi mingguan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(194, 3, 1, '2026-11-17', 'pemasukan', 165000.00, 'Penjualan dorokdok daun jeruk 11 bungkus', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'WhatsApp'),
(195, 2, 13, '2026-11-18', 'pengeluaran', 100000.00, 'Iklan Instagram dan TikTok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(196, 3, 6, '2026-11-19', 'pengeluaran', 480000.00, 'Beli kulit sapi kering tambahan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(197, 1, 4, '2026-11-20', 'pemasukan', 2000000.00, 'Tambahan modal dari pemilik', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(198, 2, 1, '2026-11-21', 'pemasukan', 330000.00, 'Penjualan dorokdok campur varian (QRIS)', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'media sosial'),
(199, 3, 12, '2026-11-22', 'pengeluaran', 175000.00, 'Servis wajan penggorengan dan sealer', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(200, 2, 3, '2026-11-23', 'pemasukan', 1500000.00, 'Pesanan grosir reseller Jakarta 6 dus', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(201, 1, 9, '2026-11-24', 'pengeluaran', 120000.00, 'Bayar air bulanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(202, 3, 2, '2026-11-25', 'pemasukan', 105000.00, 'Penjualan bumbu tabur 7 pak', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(203, 2, 7, '2026-11-26', 'pengeluaran', 95000.00, 'Beli dus kardus pengiriman', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(204, 1, 8, '2026-11-27', 'pengeluaran', 300000.00, 'Bayar gaji Siti mingguan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(205, 2, 1, '2026-11-28', 'pemasukan', 420000.00, 'Penjualan dorokdok akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(206, 3, 5, '2026-11-29', 'pemasukan', 50000.00, 'Hasil jual kardus bekas', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(207, 2, 14, '2026-11-29', 'pengeluaran', 45000.00, 'Konsumsi dan kebutuhan harian pabrik', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(208, 1, 10, '2026-11-30', 'pengeluaran', 200000.00, 'Ongkir pengiriman ke Jakarta', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(209, 2, 1, '2026-12-01', 'pemasukan', 375000.00, 'Penjualan dorokdok daun jeruk di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(210, 3, 6, '2026-12-03', 'pengeluaran', 705000.00, 'Beli kulit sapi kering dari pemasok', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(211, 3, 1, '2026-12-05', 'pemasukan', 390000.00, 'Penjualan dorokdok pedas akhir pekan di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'WhatsApp'),
(212, 1, 8, '2026-12-05', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(213, 2, 7, '2026-12-07', 'pengeluaran', 165000.00, 'Beli plastik dan label kemasan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(214, 1, 9, '2026-12-10', 'pengeluaran', 355000.00, 'Bayar listrik dan air', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(215, 2, 10, '2026-12-12', 'pengeluaran', 140000.00, 'Bensin antar pesanan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(216, 3, 11, '2026-12-14', 'pengeluaran', 140000.00, 'Isi ulang gas elpiji', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(217, 2, 1, '2026-12-16', 'pemasukan', 260000.00, 'Penjualan dorokdok original di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'WhatsApp'),
(218, 3, 6, '2026-12-17', 'pengeluaran', 565000.00, 'Beli bumbu, tepung, minyak goreng', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(219, 1, 8, '2026-12-20', 'pengeluaran', 600000.00, 'Gaji karyawan', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', NULL),
(220, 2, 2, '2026-12-22', 'pemasukan', 175000.00, 'Penjualan bumbu tabur', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(221, 1, 3, '2026-12-22', 'pemasukan', 2575000.00, 'Pesanan grosir toko oleh-oleh Garut', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'reseller/toko oleh-oleh'),
(222, 2, 1, '2026-12-24', 'pemasukan', 590000.00, 'Penjualan dorokdok libur akhir tahun', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(223, 3, 1, '2026-12-25', 'pemasukan', 360000.00, 'Penjualan dorokdok manis di WhatsApp', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'WhatsApp'),
(224, 3, 1, '2026-12-27', 'pemasukan', 585000.00, 'Penjualan dorokdok pedas akhir pekan di toko', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko'),
(225, 2, 1, '2026-12-27', 'pemasukan', 630000.00, 'Penjualan dorokdok libur akhir tahun', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'QRIS', 'toko'),
(226, 1, 3, '2026-12-28', 'pemasukan', 2150000.00, 'Pesanan grosir toko oleh-oleh Garut', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'reseller/toko oleh-oleh'),
(227, 2, 1, '2026-12-31', 'pemasukan', 595000.00, 'Penjualan dorokdok libur akhir tahun', '2026-11-20 10:01:22', '2026-11-20 10:01:22', 'tunai', 'toko');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','karyawan') NOT NULL DEFAULT 'karyawan',
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `photo_url` varchar(255) DEFAULT NULL,
  `motto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `is_active`, `created_at`, `updated_at`, `photo_url`, `motto`) VALUES
(1, 'Fajar Gustiana', 'fajar@dorokdok.com', '$2b$10$eOGumwHj7lNZGrGIZjT4beG939Auxb1MZK0OZ/fff/eeGGxayBOw2', 'admin', 1, '2026-11-20 10:01:22', '2026-11-23 07:21:08', '/uploads/1795190592527.gif', 'Membangun UMKM Go Digital!'),
(2, 'Budi Santoso', 'budi@dorokdok.com', '$2b$10$CejYKh8Xbf/qjqhinAxNw.mYfwNmvin38MCBz.Cx0zoOOe70jV2ia', 'karyawan', 1, '2026-11-20 10:01:22', '2026-11-23 07:21:49', '/uploads/1795191552001.png', 'Kerja keras hari ini, senyum esok hari.'),
(3, 'Siti Indriani', 'siti@dorokdok.com', '$2b$10$z0fbk24Hx9vO3pMxebbjzOXT95qjp3hVg/owjTcSxPHEp5p4r0/6y', 'karyawan', 1, '2026-11-20 10:01:22', '2026-11-23 07:21:41', 'https://ui-avatars.com/api/?name=Siti+Aminah&background=f59e0b&color=fff', 'Teliti dalam mencatat, cepat dalam bertindak.'),
(5, 'Ahmad Adi', 'adi@dorokdok.com', '$2b$10$AbuYsIA/Yx/gLeAbFoySBeCdG9Ow6Tc6uGj/IuhkrHNRuur/SZ.Fu', 'karyawan', 1, '2026-11-21 07:08:19', '2026-11-21 07:08:19', NULL, NULL),
(6, 'Muhammad Thoriq', 'thoriq@dorokdok.com', '$2b$10$naBTUHIgbayFQwL5whrwSu3AitapFj1METuUDSNK7hCdlXQTN.bwm', 'karyawan', 1, '2026-11-21 07:08:39', '2026-11-21 07:08:39', NULL, NULL),
(7, 'Sri Sukma', 'sri@dorokdok.com', '$2b$10$whRZeNuyGnKRhpeaNF3YduCJKcThZAFMYVfW3jvRvEm7DOIUz7RoO', 'karyawan', 1, '2026-11-21 07:09:50', '2026-11-21 07:09:50', NULL, NULL),
(8, 'Ananda', 'ananda@dorokdok.com', '$2b$10$gbzwPmyH/MS9bmDzlCjxOO2c1vlKLA7XwRB5nCWXrbJVN0iC4OBIC', 'karyawan', 1, '2026-11-22 08:53:52', '2026-11-22 08:53:52', NULL, NULL),
(9, 'Syakila Nurul', 'syakila@dorokdok.com', '$2b$10$/6LR.Sy0uagJpiooE.0iv.JRyJwpZnV2/NdSTtQL1NZ4Cyjvp4UFS', 'karyawan', 1, '2026-11-22 08:54:11', '2026-11-22 08:54:11', NULL, NULL);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `session_id` (`session_id`);

--
-- Indeks untuk tabel `chat_sessions`
--
ALTER TABLE `chat_sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `fk_parent_comment` (`parent_id`);

--
-- Indeks untuk tabel `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_comment_like` (`comment_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `general_chats`
--
ALTER TABLE `general_chats`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_like` (`post_id`,`user_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indeks untuk tabel `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `chat_messages`
--
ALTER TABLE `chat_messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- AUTO_INCREMENT untuk tabel `chat_sessions`
--
ALTER TABLE `chat_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `comments`
--
ALTER TABLE `comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT untuk tabel `comment_likes`
--
ALTER TABLE `comment_likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `general_chats`
--
ALTER TABLE `general_chats`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT untuk tabel `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=233;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `chat_messages`
--
ALTER TABLE `chat_messages`
  ADD CONSTRAINT `chat_messages_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `chat_sessions` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `chat_sessions`
--
ALTER TABLE `chat_sessions`
  ADD CONSTRAINT `chat_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comments_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_parent_comment` FOREIGN KEY (`parent_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `comment_likes`
--
ALTER TABLE `comment_likes`
  ADD CONSTRAINT `comment_likes_ibfk_1` FOREIGN KEY (`comment_id`) REFERENCES `comments` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `comment_likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `general_chats`
--
ALTER TABLE `general_chats`
  ADD CONSTRAINT `general_chats_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `likes`
--
ALTER TABLE `likes`
  ADD CONSTRAINT `likes_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `likes_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
